long comb(long n,long k);
long factorial(long n);
