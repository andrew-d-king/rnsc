#define BIG_COST 999999
#define SILENT_RUN 1
#define TAKE_STATS 1
